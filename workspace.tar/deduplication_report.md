---

### 4. Run tests

Backend:

```sh
cd gplus_smart_builder_pro
pytest
```

Frontend:

```sh
cd frontend
npm test
```

----

## Deployment Checklist

- [ ] All tests passing (backend & frontend)
- [ ] Environment variables set (no secrets in code)
- [ ] Alembic migrations up to date
- [ ] Docker images build and run successfully
- [ ] CORS and security settings reviewed
- [ ] Logging and monitoring configured
- [ ] Production database configured
- [ ] HTTPS enabled in production

----

## Environment Variables

See `.env.example` in each service for required variables.

----

## Monitoring & Logging

- Backend logs to `logs/gplus_smart_builder_pro.log` and console.
- Sentry integration available (set `SENTRY_DSN`).
- Frontend: Use `logError.js` for error reporting.

----

## License

MIT

## Overview

This is a FastAPI backend project with modular structure for authentication, CRUD, database, and API routing.

Install dependencies: `pip install -r requirements.txt`
Run the app: `python app.py`

## Project Structure

- `gplus_smart_builder_pro/src/main.py`: FastAPI entry point
- `template/backend_fastapi/src/`: Backend modules (auth, crud, database, schemas, models, routes)

## Setup

1. Install dependencies:

```pwsh
pip install fastapi uvicorn sqlalchemy pydantic
```

2. Run the backend:

```pwsh
python -m gplus_smart_builder_pro.src.main
```

3. API docs available at: [http://localhost:8000/docs](http://localhost:8000/docs)

## Next Steps

- Add more API routes in `routes/` and register them in `main.py`.
Frontend:

```sh
cd frontend
npm test
```
-## Example Endpoints
-- `/` - Root endpoint
-- `/users` - Example user endpoint
+Start developing your application in the `src/` folder. Add tests in `tests/` and update documentation in `docs/`.

```

## README.md <-> gplus-smart-builder-pro/README.md
 
- [x] Files differed. Merged into README.md, removed gplus-smart-builder-pro/README.md.
 
- [ ] Manual review recommended for README.md (see diff below):
 
```diff
--- README.md+++ gplus-smart-builder-pro/README.md@@ -1,111 +0,0 @@---- README.md+++ gplus_smart_builder_pro/README.md@@ -1,102 +1,16 @@-# GPlusApp
-+# GPlus Smart Builder Pro
- 
--A full-stack web application with a FastAPI backend and React frontend, containerized with Docker and ready for production deployment.
-+Welcome to your generated project!
- 
-----
-+## Getting Started
## Quick Start

### 1. Clone the repository

```sh
git clone https://github.com/Moo-hub/GplusAPP.git
cd GplusAPP
```

### 2. Set up environment variables

Copy `.env.example` to `.env` in both `gplus_smart_builder_pro/` and `frontend/` and fill in values.

### 3. Build and run with Docker Compose

```sh
docker-compose up --build
```

Backend: http://localhost:8000

Frontend: http://localhost:5173

### 4. Run tests

Backend:

```sh
cd gplus_smart_builder_pro
pytest
```

Frontend:

```sh
cd frontend
npm test
```
--
--### 4. Run tests
--- Backend:
--   ```sh
--   cd gplus_smart_builder_pro
--   pytest
--   ```
--- Frontend:
--   ```sh
--   cd frontend
--   npm test
--   ```
--
-----
--
--## Deployment Checklist
--- [ ] All tests passing (backend & frontend)
--- [ ] Environment variables set (no secrets in code)
--- [ ] Alembic migrations up to date
--- [ ] Docker images build and run successfully
--- [ ] CORS and security settings reviewed
--- [ ] Logging and monitoring configured
--- [ ] Production database configured
--- [ ] HTTPS enabled in production
--
-----
--
--## Environment Variables
--- See `.env.example` in each service for required variables.
--
-----
--
--## Monitoring & Logging
--- Backend logs to `logs/gplus_smart_builder_pro.log` and console.
--- Sentry integration available (set `SENTRY_DSN`).
--- Frontend: Use `logError.js` for error reporting.
--
-----
--
--## License
--MIT
--
--## Overview
--This is a FastAPI backend project with modular structure for authentication, CRUD, database, and API routing.
-+- Install dependencies: `pip install -r requirements.txt`
-+- Run the app: `python app.py`
- 
- ## Project Structure
--- `gplus_smart_builder_pro/src/main.py`: FastAPI entry point
--- `template/backend_fastapi/src/`: Backend modules (auth, crud, database, schemas, models, routes)
--
--## Setup
--1. Install dependencies:
--   ```pwsh
--   pip install fastapi uvicorn sqlalchemy pydantic
--   ```
--2. Run the backend:
--   ```pwsh
--   python -m gplus_smart_builder_pro.src.main
--   ```
--3. API docs available at: [http://localhost:8000/docs](http://localhost:8000/docs)
-+- `src/` - Main source code
-+- `tests/` - Test suite
-+- `docs/` - Documentation
- 
- ## Next Steps
--- Add more API routes in `routes/` and register them in `main.py`.
--- Implement real business logic and database integration.
--- Use git and GitHub for version control and collaboration.
--
--## Example Endpoints
--- `/` - Root endpoint
--- `/users` - Example user endpoint
-+Start developing your application in the `src/` folder. Add tests in `tests/` and update documentation in `docs/`.

```

## requirements.txt <-> gplus_smart_builder_pro/requirements.txt
- [x] Files differed. Merged into requirements.txt, removed gplus_smart_builder_pro/requirements.txt.
- [ ] Manual review recommended for requirements.txt (see diff below):

```
--- requirements.txt+++ gplus_smart_builder_pro/requirements.txt@@ -4,4 +4,9 @@ PyYAML>=6.0
 pydantic>=2.0.0
 python-dotenv>=1.0.0
-cryptography>=41.0.0 # Used for security manager+cryptography>=41.0.0 # Used for security manager
+fastapi
+uvicorn[standard]
+sqlalchemy
+alembic
+psycopg2-binary

```

## requirements.txt <-> gplus-smart-builder-pro/requirements.txt
- [x] Files differed. Merged into requirements.txt, removed gplus-smart-builder-pro/requirements.txt.
- [ ] Manual review recommended for requirements.txt (see diff below):

```
--- requirements.txt+++ gplus-smart-builder-pro/requirements.txt@@ -1,9 +0,0 @@---- requirements.txt+++ gplus_smart_builder_pro/requirements.txt@@ -4,4 +4,9 @@ PyYAML>=6.0
- pydantic>=2.0.0
- python-dotenv>=1.0.0
--cryptography>=41.0.0 # Used for security manager+cryptography>=41.0.0 # Used for security manager
-+fastapi
-+uvicorn[standard]
-+sqlalchemy
-+alembic
-+psycopg2-binary

```

## Dockerfile <-> backend/Dockerfile
- [x] Files differed. Merged into Dockerfile, removed backend/Dockerfile.
- [ ] Manual review recommended for Dockerfile (see diff below):

```
--- Dockerfile+++ backend/Dockerfile@@ -1,7 +1,18 @@-# Backend Dockerfile
-FROM python:3.10-slim
+# Base image
+FROM python:3.11-slim
+
+# Set work directory
 WORKDIR /app
-COPY requirements.txt ./
+
+# Install dependencies
+COPY requirements.txt .
 RUN pip install --no-cache-dir -r requirements.txt
+
+# Copy source code
 COPY . .
-CMD alembic upgrade head && uvicorn gplus_smart_builder_pro.src.main:app --host 0.0.0.0 --port 8000
+
+# Expose port
+EXPOSE 8000
+
+# Command to run FastAPI with Uvicorn
+CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]

```

## Dockerfile <-> frontend/Dockerfile
- [x] Files differed. Merged into Dockerfile, removed frontend/Dockerfile.
- [ ] Manual review recommended for Dockerfile (see diff below):

```
--- Dockerfile+++ frontend/Dockerfile@@ -1,22 +1,10 @@---- Dockerfile+++ backend/Dockerfile@@ -1,7 +1,18 @@-# Backend Dockerfile
--FROM python:3.10-slim
-+# Base image
-+FROM python:3.11-slim
-+
-+# Set work directory
- WORKDIR /app
--COPY requirements.txt ./
-+
-+# Install dependencies
-+COPY requirements.txt .
- RUN pip install --no-cache-dir -r requirements.txt
-+
-+# Copy source code
- COPY . .
--CMD alembic upgrade head && uvicorn gplus_smart_builder_pro.src.main:app --host 0.0.0.0 --port 8000
-+
-+# Expose port
-+EXPOSE 8000
-+
-+# Command to run FastAPI with Uvicorn
-+CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
+# Frontend Dockerfile
+FROM node:20-alpine
+WORKDIR /app
+COPY package.json ./
+COPY vite.config.js ./
+COPY index.html ./
+COPY src ./src
+RUN npm install && npm run build
+EXPOSE 5173
+CMD ["npx", "vite", "preview", "--host"]

```

## app.py <-> gplus_smart_builder_pro/app.py
- [x] Files differed. Merged into app.py, removed gplus_smart_builder_pro/app.py.
- [ ] Manual review recommended for app.py (see diff below):

```
--- app.py+++ gplus_smart_builder_pro/app.py@@ -1,597 +1,9 @@-# app.py
-
 #!/usr/bin/env python3
 # -*- coding: utf-8 -*-
 
 """
-GPlus Smart Builder Pro - Main CLI Application
-Version: 2.3.0 (Full project generation & enhanced user interaction)
-
-This file contains the main CLI application built with Typer,
-utilizing the core functionalities from gplus_core.py.
-
-Key Features:
-- Initialize new projects or components based on templates.
-- Display application information.
-- Perform various utility operations like cleanup.
-- Includes a powerful 'new' command to generate the entire project structure
-  based on a flexible project_template.yaml and user choices.
+Entry point for GPlus Smart Builder Pro generated project.
 """
 
-import sys
-import os
-import shutil
-import json
-from pathlib import Path
-from typing import Optional, List, Dict, Any, Set, Union
-import yaml
-import typer
-from rich.console import Console
-from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn, TimeElapsedColumn, TimeRemainingColumn
-from rich.prompt import Confirm, Prompt
-from rich.panel import Panel
-from rich.table import Table
-from datetime import datetime
-
-# Import all necessary components from gplus_core
-from gplus_core import (
-    app_config, AppError, ConfigError, TemplateError, ValidationError, BuildError,
-    get_security_manager, get_template_manager, get_app_queue, get_resource_limiter,
-    run_command, create_venv_if_not_exists, install_dependencies_in_venv,
-    cleanup_temp_dirs, clear_cache_and_logs, detect_project_type,
-    log_debug, log_info, log_warning, log_error, log_critical, log_success,
-    get_localized_message, detect_system_language,
-    ProjectStructureConfig, FeatureFlag, ValueFeature,
-    display_app_info, DEFAULT_LANGUAGE_NAMES, error_handler,
-    console, ERROR_STYLE, INFO_STYLE, WARNING_STYLE, SUCCESS_STYLE # Import console and styles directly
-)
-
-# Initialize Typer app
-app = typer.Typer(
-    name=app_config.APP_NAME,
-    help=get_localized_message("app_help_message", detect_system_language()),
-    no_args_is_help=True,
-    add_completion=False # We can add it back later if needed
-)
-
-# Global options for Typer
-_initial_lang = detect_system_language() # Detect once at start for initial messages
-
-@app.callback()
-def main_callback(
-    ctx: typer.Context,
-    lang: Optional[str] = typer.Option(
-        None,
-        "--lang", "-l",
-        help=get_localized_message("lang_option_help", _initial_lang),
-        rich_help_panel=get_localized_message("general_options_panel", _initial_lang)
-    ),
-    debug: bool = typer.Option(
-        False,
-        "--debug",
-        help=get_localized_message("debug_option_help", _initial_lang),
-        rich_help_panel=get_localized_message("general_options_panel", _initial_lang)
-    )
-):
-    """
-    Global callback for the GPlus Smart Builder Pro CLI.
-    Initializes configuration and sets up language and logging.
-    """
-    global _initial_lang # Ensure we can update the global lang if specified by user
-
-    # Set debug mode early
-    if debug:
-        log_debug(get_localized_message("debug_mode_enabled", _initial_lang))
-        app_config.config_data["LOG_LEVEL"] = "DEBUG"
-        app_config._setup_logging() # Re-setup logging to apply new level
-
-    # Apply language setting
-    if lang:
-        if lang in app_config.SUPPORTED_LANGUAGES:
-            _initial_lang = lang # Update the global language for subsequent messages
-            log_info(get_localized_message("language_set_to", _initial_lang, lang_code=lang))
-        else:
-            log_warning(get_localized_message("language_not_supported_cli", _initial_lang, lang_code=lang, supported_languages=", ".join(app_config.SUPPORTED_LANGUAGES)))
-            console.print(f"[{WARNING_STYLE}]{get_localized_message('language_not_supported_cli', _initial_lang, lang_code=lang, supported_languages=', '.join(app_config.SUPPORTED_LANGUAGES))}[/]", style=WARNING_STYLE)
-
-    # Ensure app_config is initialized for this context, especially after lang/debug changes
-    # (Though it's a singleton and initialized once, this ensures any changes from CLI options are reflected)
-    _ = app_config # Accessing it ensures initialization
-
-
-# --- CLI Commands ---
-
-@app.command(name="about")
-@error_handler
-def about_command():
-    """
-    Displays detailed information about the application and its environment.
-    """
-    lang = detect_system_language() # Get current language from detection (potentially overridden by --lang)
-    display_app_info(lang)
-
-@app.command(name="cleanup")
-@error_handler
-def cleanup_command(
-    confirm: bool = typer.Option(False, "--yes", "-y", help=get_localized_message("cleanup_confirm_help", _initial_lang)),
-    all_temp: bool = typer.Option(False, "--all", "-a", help=get_localized_message("cleanup_all_temp_help", _initial_lang))
-):
-    """
-    Cleans up temporary directories (logs, cache).
-    Use --all to remove all temporary directories.
-    """
-    lang = detect_system_language()
-
-    if not confirm:
-        if not Confirm.ask(get_localized_message("cleanup_confirmation_prompt", lang), default=False, console=console):
-            log_info(get_localized_message("cleanup_cancelled", lang))
-            raise typer.Exit()
-
-    if all_temp:
-        clear_cache_and_logs(lang)
-    else:
-        # For granular control, could prompt which temp dirs if --all is not used
-        # For now, if --all is not used, still clear default cache/logs
-        clear_cache_and_logs(lang)
-
-    log_success(get_localized_message("cleanup_complete", lang))
-
-
-@app.command(name="new")
-@error_handler
-def new_project_command(
-    project_name: str = typer.Argument(..., help=get_localized_message("project_name_arg_help", _initial_lang)),
-    output_dir: Path = typer.Option(
-        Path.cwd(),
-        "--output", "-o",
-        help=get_localized_message("output_dir_option_help", _initial_lang),
-        exists=False,
-        file_okay=False,
-        dir_okay=True,
-        writable=True,
-        resolve_path=True
-    ),
-    template_config_file: Path = typer.Option(
-        app_config.GENERATOR_TEMPLATES_DIR_PATH / "project_template.yaml",
-        "--template-config", "-t",
-        help=get_localized_message("template_config_option_help", _initial_lang),
-        exists=True,
-        file_okay=True,
-        dir_okay=False,
-        readable=True,
-        resolve_path=True
-    ),
-    skip_confirmation: bool = typer.Option(False, "--yes", "-y", help=get_localized_message("skip_confirmation_option_help", _initial_lang)),
-    components: Optional[List[str]] = typer.Option(
-        None,
-        "--component", "-c",
-        help=get_localized_message("component_option_help", _initial_lang),
-    ),
-    features: Optional[List[str]] = typer.Option(
-        None,
-        "--feature", "-f",
-        help=get_localized_message("feature_option_help", _initial_lang),
-    ),
-    values: Optional[List[str]] = typer.Option(
-        None,
-        "--value", "-v",
-        help=get_localized_message("value_option_help", _initial_lang),
-    ),
-):
-    """
-    Generates a new project based on the selected template and features.
-    """
-    lang = detect_system_language()
-    log_info(get_localized_message("generating_new_project", lang, name=project_name, dir=output_dir))
-
-    template_manager = get_template_manager()
-    security_manager = get_security_manager() # For token generation in templates
-    app_queue = get_app_queue() # For post-generation commands
-
-    project_slug = project_name.lower().replace(" ", "-").replace("_", "-")
-    project_root = output_dir / project_slug
-
-    if project_root.exists():
-        if Confirm.ask(get_localized_message("project_dir_exists_prompt", lang, dir=project_root), default=False, console=console):
-            shutil.rmtree(project_root)
-            log_warning(get_localized_message("existing_project_dir_removed", lang, dir=project_root))
-        else:
-            log_error(get_localized_message("project_generation_cancelled", lang))
-            raise typer.Exit(1)
-
-    try:
-        # 1. Load Project Structure Configuration
-        log_info(get_localized_message("loading_project_config", lang, file=template_config_file))
-        # Use template manager to load config as a template first for Jinja pre-processing
-        template_content = template_manager.render_template(str(template_config_file.relative_to(app_config.GENERATOR_TEMPLATES_DIR_PATH)), context={
-            "app_config": app_config,
-            "security_manager": security_manager,
-            "project": {
-                "name": project_name,
-                "slug": project_slug,
-                "output_dir": str(project_root) # For template rendering if needed
-            }
-        })
-        project_config_data = yaml.safe_load(template_content)
-        project_structure = ProjectStructureConfig(**project_config_data)
-        log_success(get_localized_message("project_config_loaded", lang))
-
-        # 2. Collect user choices (Features, Values, Components)
-        selected_components_names: Set[str] = set()
-        chosen_feature_flags: Dict[str, bool] = {} # {feature_name: value}
-        chosen_value_features: Dict[str, Union[str, int, bool]] = {} # {value_name: value}
-
-        # Pre-process CLI provided components/features/values
-        if components:
-            selected_components_names.update(components)
-        if features:
-            for f in features:
-                if "=" in f: # e.g., --feature "debug_mode=true"
-                    key, val = f.split("=", 1)
-                    chosen_feature_flags[key] = val.lower() == 'true'
-                else: # e.g., --feature "debug_mode" (implies true)
-                    chosen_feature_flags[f] = True
-        if values:
-            for v in values:
-                if "=" in v:
-                    key, val = v.split("=", 1)
-                    chosen_value_features[key] = val # Store as string, convert type later
-
-        # Interactive prompts for global features/values if not provided via CLI
-        log_info(get_localized_message("collecting_user_input", lang))
-
-        # Global Feature Flags
-        for flag_name, flag_obj in project_structure.global_feature_flags.items():
-            if flag_name not in chosen_feature_flags:
-                prompt_text = get_localized_message("prompt_enable_feature", lang, feature_name=flag_obj.description)
-                chosen_feature_flags[flag_name] = Confirm.ask(prompt_text, default=flag_obj.default, console=console)
-            else:
-                log_debug(f"Global feature '{flag_name}' overridden by CLI to {chosen_feature_flags[flag_name]}.")
-
-        # Global Value Features
-        for value_name, value_obj in project_structure.global_value_features.items():
-            if value_name not in chosen_value_features:
-                prompt_text = value_obj.prompt or get_localized_message("prompt_enter_value", lang, value_name=value_obj.description, default=value_obj.default)
-                user_input = Prompt.ask(prompt_text, default=str(value_obj.default), console=console)
-                try:
-                    if value_obj.type == "int":
-                        chosen_value_features[value_name] = int(user_input)
-                    elif value_obj.type == "bool":
-                        chosen_value_features[value_name] = user_input.lower() in ['true', '1', 'yes', 'y']
-                    else: # str
-                        chosen_value_features[value_name] = user_input
-                except ValueError:
-                    log_warning(get_localized_message("invalid_value_type_warning", lang, value=user_input, type=value_obj.type, name=value_name))
-                    console.print(f"[{WARNING_STYLE}]{get_localized_message('invalid_value_type_warning', lang, value=user_input, type=value_obj.type, name=value_name)}. Using default.[/]")
-                    chosen_value_features[value_name] = value_obj.default # Fallback to default
-            else:
-                # Convert CLI provided value to correct type based on schema
-                try:
-                    cli_val = chosen_value_features[value_name]
-                    if value_obj.type == "int":
-                        chosen_value_features[value_name] = int(cli_val)
-                    elif value_obj.type == "bool":
-                        chosen_value_features[value_name] = str(cli_val).lower() in ['true', '1', 'yes', 'y']
-                    # str is already handled
-                except ValueError:
-                    log_warning(f"CLI provided value '{cli_val}' for '{value_name}' cannot be converted to type '{value_obj.type}'. Using default.")
-                    console.print(f"[{WARNING_STYLE}]CLI provided value '{cli_val}' for '{value_name}' cannot be converted to type '{value_obj.type}'. Using default.[/]")
-                    chosen_value_features[value_name] = value_obj.default
-                log_debug(f"Global value '{value_name}' overridden by CLI to {chosen_value_features[value_name]}.")
-
-        # Component Selection
-        available_component_names = [comp.name for comp in project_structure.components]
-        if not components: # If no components provided via CLI, prompt interactively
-            console.print(Panel(get_localized_message("select_components_title", lang), expand=False, style=INFO_STYLE))
-            for i, comp in enumerate(project_structure.components):
-                console.print(f"  [bold blue]{i+1}. {comp.name}[/bold blue] - [cyan]{comp.description}[/cyan]")
-
-            selected_indices: List[int] = []
-            while True:
-                input_str = Prompt.ask(get_localized_message("prompt_select_components", lang), default="", console=console)
-                if not input_str: # Allow skipping if no components required
-                    break
-                try:
-                    current_selection = sorted(list(set(int(x.strip()) for x in input_str.split(','))))
-                    if all(1 <= idx <= len(project_structure.components) for idx in current_selection):
-                        selected_indices = current_selection
-                        break
-                    else:
-                        console.print(f"[{WARNING_STYLE}]{get_localized_message('invalid_component_selection', lang)}[/]")
-                except ValueError:
-                    console.print(f"[{WARNING_STYLE}]{get_localized_message('invalid_input', lang)}[/]")
-            selected_components_names.update(project_structure.components[idx-1].name for idx in selected_indices)
-        else:
-            # Validate CLI components
-            for comp_name in selected_components_names:
-                if comp_name not in available_component_names:
-                    raise ValidationError(get_localized_message("invalid_component_cli", lang, component=comp_name, available=", ".join(available_component_names)))
-            log_debug(f"Components selected via CLI: {selected_components_names}")
-
-
-        # Component-specific optional features
-        component_feature_choices: Dict[str, Dict[str, bool]] = {} # {comp_name: {feature_name: value}}
-        for comp in project_structure.components:
-            if comp.name in selected_components_names:
-                component_feature_choices[comp.name] = {}
-                for feat_name, feat_desc in comp.optional_features.items():
-                    # Check if this feature was explicitly set via CLI (--feature component_name.feature_name=true)
-                    cli_override_key = f"{comp.name}.{feat_name}"
-                    if cli_override_key in chosen_feature_flags:
-                        component_feature_choices[comp.name][feat_name] = chosen_feature_flags[cli_override_key]
-                        log_debug(f"Component feature '{cli_override_key}' overridden by CLI to {chosen_feature_flags[cli_override_key]}.")
-                    else:
-                        prompt_text = get_localized_message("prompt_enable_component_feature", lang, component_name=comp.name, feature_name=feat_desc)
-                        component_feature_choices[comp.name][feat_name] = Confirm.ask(prompt_text, default=False, console=console) # Default to false for optional features
-
-        # 3. Prepare Jinja2 Context
-        global_context: Dict[str, Any] = {
-            "project": {
-                "name": project_name,
-                "slug": project_slug,
-                "current_year": datetime.now().year,
-                "author": app_config.AUTHOR,
-                "version": app_config.APP_VERSION,
-                "description": project_structure.description,
-                "root_dir": str(project_root)
-            },
-            "global_features": chosen_feature_flags, # Renamed from 'features' to avoid confusion with component features
-            "value_features": chosen_value_features,
-            "component_features": component_feature_choices, # New: {comp_name: {feat_name: bool}}
-            "app_config": app_config, # Access global app configuration
-            "security_manager": security_manager, # Access security manager for token generation
-        }
-        # Fix: Only log serializable parts of global_context to avoid JSON serialization errors
-        try:
-            serializable_context = {k: v for k, v in global_context.items() if isinstance(v, (str, int, float, bool, list, dict, type(None)))}
-            log_debug(f"Jinja2 Context: {json.dumps(serializable_context, indent=2)}")
-        except Exception as e:
-            log_debug(f"Could not serialize global_context for debug: {e}")
-
-        if not skip_confirmation:
-            console.print(Panel(get_localized_message("project_summary_title", lang), expand=False, style=INFO_STYLE))
-            console.print(f"[bold]Project Name:[/bold] {project_name}")
-            console.print(f"[bold]Output Directory:[/bold] {project_root}")
-            console.print("[bold]Global Features:[/bold]")
-            if global_context["global_features"]:
-                for k, v in global_context["global_features"].items():
-                    console.print(f"  - {k}: [magenta]{v}[/magenta]")
-            else:
-                console.print("  [dim]None[/dim]")
-
-            console.print("[bold]Global Values:[/bold]")
-            if global_context["value_features"]:
-                for k, v in global_context["value_features"].items():
-                    console.print(f"  - {k}: [magenta]{v}[/magenta] (Type: {project_structure.global_value_features.get(k).type})")
-            else:
-                console.print("  [dim]None[/dim]")
-
-            console.print("[bold]Selected Components:[/bold]")
-            if selected_components_names:
-                for comp_name in selected_components_names:
-                    console.print(f"  - [green]{comp_name}[/green]")
-                    if comp_name in component_feature_choices:
-                        for feat_name, enabled in component_feature_choices[comp_name].items():
-                            console.print(f"    - Feature '{feat_name}': [magenta]{enabled}[/magenta]")
-            else:
-                console.print("  [dim]None[/dim]")
-
-            if not Confirm.ask(get_localized_message("proceed_with_generation_prompt", lang), default=True, console=console):
-                log_info(get_localized_message("project_generation_cancelled", lang))
-                raise typer.Exit(1)
-
-        # 4. Create Project Root Directory
-        log_info(get_localized_message("creating_project_root", lang, path=project_root))
-        project_root.mkdir(parents=True, exist_ok=False)
-        log_success(get_localized_message("project_root_created", lang, path=project_root))
-
-        # 5. Create root .env and .gitignore files
-        create_root_project_files(project_root, global_context, lang)
-
-        # 6. Generate Project Components
-        with Progress(
-            SpinnerColumn(),
-            TextColumn("[progress.description]{task.description}"),
-            BarColumn(),
-            TaskProgressColumn(),
-            TimeRemainingColumn(),
-            TimeElapsedColumn(),
-            console=console
-        ) as progress:
-            main_task = progress.add_task(get_localized_message("generating_components_progress", lang), total=len(selected_components_names) + 1) # +1 for root files
-
-            # Mark root files task as complete (it's already done)
-            progress.update(main_task, advance=1)
-
-            for component_config in project_structure.components:
-                if component_config.name in selected_components_names:
-                    log_info(get_localized_message("generating_component", lang, component=component_config.name))
-                    component_task = progress.add_task(f"[bold magenta]{component_config.name}[/bold magenta]", total=1) # Task per component
-
-                    # Render the component's output path in case it contains Jinja2 variables
-                    rendered_output_path_str = template_manager.render_string(component_config.output_path, global_context)
-                    component_output_path = project_root / rendered_output_path_str
-                    component_output_path.mkdir(parents=True, exist_ok=True)
-                    log_debug(f"Component '{component_config.name}' output path: {component_output_path}")
-
-                    # Process files
-                    for file_config in component_config.files:
-                        condition_met = True
-                        if file_config.condition:
-                            try:
-                                # Evaluate Jinja2 condition
-                                condition_met = template_manager.render_string("{{ " + file_config.condition + " }}", global_context).lower() == 'true'
-                            except Exception as e:
-                                log_warning(f"Failed to evaluate condition '{file_config.condition}' for file '{file_config.source}': {e}. Skipping file.", error_obj=e)
-                                console.print(f"[{WARNING_STYLE}]{get_localized_message('condition_eval_failed_warning', lang, file=file_config.source, condition=file_config.condition)}[/]")
-                                condition_met = False
-
-                        if condition_met:
-                            source_file_rel_path = Path(component_config.template_path) / file_config.source
-                            # Render rename path if it contains Jinja2
-                            final_file_name = file_config.source
-                            if file_config.rename:
-                                final_file_name = template_manager.render_string(file_config.rename, global_context)
-                            # Remove .jinja suffix if present in source and output
-                            if source_file_rel_path.suffix == ".jinja":
-                                final_file_name = Path(final_file_name).stem # Remove .jinja from output name
-                            destination_file_path = component_output_path / final_file_name
-
-                            template_manager.copy_and_render_template_file(
-                                source_file_rel_path,
-                                destination_file_path,
-                                global_context,
-                                lang
-                            )
-
-                    # Process directories
-                    for dir_config in component_config.directories:
-                        condition_met = True
-                        if dir_config.condition:
-                            try:
-                                condition_met = template_manager.render_string("{{ " + dir_config.condition + " }}", global_context).lower() == 'true'
-                            except Exception as e:
-                                log_warning(f"Failed to evaluate condition '{dir_config.condition}' for directory '{dir_config.source}': {e}. Skipping directory.", error_obj=e)
-                                console.print(f"[{WARNING_STYLE}]{get_localized_message('condition_eval_failed_warning', lang, file=dir_config.source, condition=dir_config.condition)}[/]")
-                                condition_met = False
-
-                        if condition_met:
-                            source_dir_rel_path = Path(component_config.template_path) / dir_config.source
-                            # Render rename path if it contains Jinja2
-                            final_dir_name = dir_config.source
-                            if dir_config.rename:
-                                final_dir_name = template_manager.render_string(dir_config.rename, global_context)
-
-                            destination_dir_path = component_output_path / final_dir_name
-
-                            template_manager.copy_and_render_template_directory(
-                                source_dir_rel_path,
-                                destination_dir_path,
-                                global_context,
-                                lang,
-                                component_output_path # Pass the component's actual output path
-                            )
-
-                    # Add post-generation commands to queue
-                    for command_config in component_config.post_generation_commands:
-                        command_list = command_config["command"]
-                        condition_met_for_command = True
-                        if "condition" in command_config:
-                            try:
-                                condition_met_for_command = template_manager.render_string("{{ " + command_config["condition"] + " }}", global_context).lower() == 'true'
-                            except Exception as e:
-                                log_warning(f"Failed to evaluate condition '{command_config['condition']}' for post-gen command '{command_list}': {e}. Skipping command.", error_obj=e)
-                                console.print(f"[{WARNING_STYLE}]{get_localized_message('condition_eval_failed_warning', lang, file='post-gen command', condition=command_config['condition'])}[/]")
-                                condition_met_for_command = False
-
-                        if condition_met_for_command:
-                            # Render command arguments with Jinja2 context if they contain variables
-                            rendered_command_list = [template_manager.render_string(arg, global_context) for arg in command_list]
-                            app_queue.add_task(
-                                run_command,
-                                rendered_command_list,
-                                component_output_path, # Run command in component's root
-                                get_localized_message("running_post_gen_command", lang, command=" ".join(rendered_command_list[:3]) + "..."),
-                                lang,
-                                get_localized_message("post_gen_command_failed", lang, command=" ".join(rendered_command_list[:3]) + "..."),
-                                # progress_task=main_task # Optionally link to main task for progress updates
-                            )
-                            log_debug(f"Added post-generation command to queue: {rendered_command_list}")
-
-                    progress.update(component_task, advance=1) # Mark component task complete
-                    log_success(get_localized_message("component_generated_success", lang, component=component_config.name))
-            progress.stop_task(main_task)
-
-        log_success(get_localized_message("project_generation_complete", lang, name=project_name, path=project_root))
-
-        # 7. Run Post-Generation Commands (from queue)
-        if not app_queue.is_empty():
-            console.print(Panel(get_localized_message("running_post_gen_commands_title", lang), expand=False, style=INFO_STYLE))
-            app_queue.run_all_tasks(with_progress=True, lang=lang)
-            log_success(get_localized_message("all_post_gen_commands_complete", lang))
-        else:
-            log_info(get_localized_message("no_post_gen_commands", lang))
-
-        console.print(Panel(get_localized_message("next_steps_title", lang), expand=False, style=SUCCESS_STYLE))
-        console.print(get_localized_message("next_steps_cd", lang, project_path=project_root))
-        console.print(get_localized_message("next_steps_install_deps", lang))
-        console.print(get_localized_message("next_steps_run_app", lang))
-        console.print(get_localized_message("next_steps_read_docs", lang, docs_path=f"{project_root}/docs"))
-
-
-    except ValidationError as e:
-        log_error(f"Project configuration validation failed: {e.message}", lang=lang, error_obj=e.original_exception)
-        console.print(f"[{ERROR_STYLE}]{get_localized_message('project_config_validation_failed', lang, error=e.message)}[/]", style=ERROR_STYLE)
-        raise typer.Exit(1)
-    except AppError as e:
-        log_error(f"Project generation failed: {e.message}", lang=lang, error_obj=e.original_exception)
-        console.print(
-            f"[{ERROR_STYLE}]{get_localized_message('project_generation_failed', lang, error=e.message, default='Project generation failed: {error}')}"
-            f"[/]", style=ERROR_STYLE
-        )
-        raise typer.Exit(1)
-    except Exception as e:
-        log_critical(f"An unexpected error occurred during project generation: {e}", lang=lang, error_obj=e)
-        console.print(
-            f"[{ERROR_STYLE}]{get_localized_message('project_generation_failed_unexpected', lang, error=str(e), default='An unexpected error occurred during project generation: {error}')}"
-            f"[/]", style=ERROR_STYLE
-        )
-        raise typer.Exit(1)
-
-def create_root_project_files(project_root: Path, global_context: Dict[str, Any], lang: str):
-    """
-    Creates the root .env and .gitignore files for the new project.
-    These are generated from simple Jinja strings defined in localization files.
-    """
-    template_manager = get_template_manager()
-    try:
-        # Create .env file
-        env_template_content = get_localized_message("root_env_template", lang)
-        env_content = template_manager.render_string(env_template_content, global_context)
-        (project_root / ".env").write_text(env_content, encoding='utf-8')
-        log_success(get_localized_message("root_env_created", lang), lang=lang)
-
-        # Create .gitignore file
-        gitignore_template_content = get_localized_message("root_gitignore_template", lang)
-        gitignore_content = template_manager.render_string(gitignore_template_content, global_context)
-        (project_root / ".gitignore").write_text(gitignore_content, encoding='utf-8')
-        log_success(get_localized_message("root_gitignore_created", lang), lang=lang)
-
-    except AppError as e:
-        log_error(f"Error creating root project files: {e.message}", lang=lang, error_obj=e.original_exception)
-        console.print(f"[{ERROR_STYLE}]{get_localized_message('root_file_creation_failed', lang, error=e.message)}[/]", style=ERROR_STYLE)
-        raise typer.Exit(1)
-    except Exception as e:
-        log_critical(f"An unexpected error occurred creating root project files: {e}", lang=lang, error_obj=e)
-        console.print(f"[{ERROR_STYLE}]{get_localized_message('root_file_creation_failed_unexpected', lang, error=str(e))}[/]", style=ERROR_STYLE)
-        raise typer.Exit(1)
-
-# You need to install the 'typer' package (and optionally 'rich' for better CLI output).
-# Run the following command in your terminal:
-#   pip install typer[all] rich
-
-# Main entry point for Typer app
-if __name__ == "__main__":
-    # Ensure required dependencies are installed
-    try:
-        import typer
-        import rich
-    except ImportError:
-        print("Missing required packages. Please run:\n  pip install typer[all] rich", file=sys.stderr)
-        sys.exit(1)
-    # Ensure logging and localization are set up before any command runs
-    try:
-        app()
-    except typer.Exit:
-        pass
-    except SystemExit:
-        pass # Typer sometimes exits via SystemExit
-    except Exception as e:
-        # Catch any remaining unexpected errors at the very top level
-        log_critical(
-            get_localized_message('unexpected_command_error', _initial_lang, command='application runtime', error=str(e)),
-            lang=_initial_lang,
-            error_obj=e
-        )
-        console.print(f"[{ERROR_STYLE}]{get_localized_message('unexpected_command_error', _initial_lang, command='application runtime', error=str(e))}[/]", style=ERROR_STYLE)
-        sys.exit(1)
+print("Welcome to GPlus Smart Builder Pro!")
+# Add your project startup logic here.

```

## app.py <-> gplus-smart-builder-pro/app.py
- [x] Files differed. Merged into app.py, removed gplus-smart-builder-pro/app.py.
- [ ] Manual review recommended for app.py (see diff below):

```
--- app.py+++ gplus-smart-builder-pro/app.py@@ -1,600 +0,0 @@---- app.py+++ gplus_smart_builder_pro/app.py@@ -1,597 +1,9 @@-# app.py
--
- #!/usr/bin/env python3
- # -*- coding: utf-8 -*-
- 
- """
--GPlus Smart Builder Pro - Main CLI Application
--Version: 2.3.0 (Full project generation & enhanced user interaction)
--
--This file contains the main CLI application built with Typer,
--utilizing the core functionalities from gplus_core.py.
--
--Key Features:
--- Initialize new projects or components based on templates.
--- Display application information.
--- Perform various utility operations like cleanup.
--- Includes a powerful 'new' command to generate the entire project structure
--  based on a flexible project_template.yaml and user choices.
-+Entry point for GPlus Smart Builder Pro generated project.
- """
- 
--import sys
--import os
--import shutil
--import json
--from pathlib import Path
--from typing import Optional, List, Dict, Any, Set, Union
--import yaml
--import typer
--from rich.console import Console
--from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn, TimeElapsedColumn, TimeRemainingColumn
--from rich.prompt import Confirm, Prompt
--from rich.panel import Panel
--from rich.table import Table
--from datetime import datetime
--
--# Import all necessary components from gplus_core
--from gplus_core import (
--    app_config, AppError, ConfigError, TemplateError, ValidationError, BuildError,
--    get_security_manager, get_template_manager, get_app_queue, get_resource_limiter,
--    run_command, create_venv_if_not_exists, install_dependencies_in_venv,
--    cleanup_temp_dirs, clear_cache_and_logs, detect_project_type,
--    log_debug, log_info, log_warning, log_error, log_critical, log_success,
--    get_localized_message, detect_system_language,
--    ProjectStructureConfig, FeatureFlag, ValueFeature,
--    display_app_info, DEFAULT_LANGUAGE_NAMES, error_handler,
--    console, ERROR_STYLE, INFO_STYLE, WARNING_STYLE, SUCCESS_STYLE # Import console and styles directly
--)
--
--# Initialize Typer app
--app = typer.Typer(
--    name=app_config.APP_NAME,
--    help=get_localized_message("app_help_message", detect_system_language()),
--    no_args_is_help=True,
--    add_completion=False # We can add it back later if needed
--)
--
--# Global options for Typer
--_initial_lang = detect_system_language() # Detect once at start for initial messages
--
--@app.callback()
--def main_callback(
--    ctx: typer.Context,
--    lang: Optional[str] = typer.Option(
--        None,
--        "--lang", "-l",
--        help=get_localized_message("lang_option_help", _initial_lang),
--        rich_help_panel=get_localized_message("general_options_panel", _initial_lang)
--    ),
--    debug: bool = typer.Option(
--        False,
--        "--debug",
--        help=get_localized_message("debug_option_help", _initial_lang),
--        rich_help_panel=get_localized_message("general_options_panel", _initial_lang)
--    )
--):
--    """
--    Global callback for the GPlus Smart Builder Pro CLI.
--    Initializes configuration and sets up language and logging.
--    """
--    global _initial_lang # Ensure we can update the global lang if specified by user
--
--    # Set debug mode early
--    if debug:
--        log_debug(get_localized_message("debug_mode_enabled", _initial_lang))
--        app_config.config_data["LOG_LEVEL"] = "DEBUG"
--        app_config._setup_logging() # Re-setup logging to apply new level
--
--    # Apply language setting
--    if lang:
--        if lang in app_config.SUPPORTED_LANGUAGES:
--            _initial_lang = lang # Update the global language for subsequent messages
--            log_info(get_localized_message("language_set_to", _initial_lang, lang_code=lang))
--        else:
--            log_warning(get_localized_message("language_not_supported_cli", _initial_lang, lang_code=lang, supported_languages=", ".join(app_config.SUPPORTED_LANGUAGES)))
--            console.print(f"[{WARNING_STYLE}]{get_localized_message('language_not_supported_cli', _initial_lang, lang_code=lang, supported_languages=', '.join(app_config.SUPPORTED_LANGUAGES))}[/]", style=WARNING_STYLE)
--
--    # Ensure app_config is initialized for this context, especially after lang/debug changes
--    # (Though it's a singleton and initialized once, this ensures any changes from CLI options are reflected)
--    _ = app_config # Accessing it ensures initialization
--
--
--# --- CLI Commands ---
--
--@app.command(name="about")
--@error_handler
--def about_command():
--    """
--    Displays detailed information about the application and its environment.
--    """
--    lang = detect_system_language() # Get current language from detection (potentially overridden by --lang)
--    display_app_info(lang)
--
--@app.command(name="cleanup")
--@error_handler
--def cleanup_command(
--    confirm: bool = typer.Option(False, "--yes", "-y", help=get_localized_message("cleanup_confirm_help", _initial_lang)),
--    all_temp: bool = typer.Option(False, "--all", "-a", help=get_localized_message("cleanup_all_temp_help", _initial_lang))
--):
--    """
--    Cleans up temporary directories (logs, cache).
--    Use --all to remove all temporary directories.
--    """
--    lang = detect_system_language()
--
--    if not confirm:
--        if not Confirm.ask(get_localized_message("cleanup_confirmation_prompt", lang), default=False, console=console):
--            log_info(get_localized_message("cleanup_cancelled", lang))
--            raise typer.Exit()
--
--    if all_temp:
--        clear_cache_and_logs(lang)
--    else:
--        # For granular control, could prompt which temp dirs if --all is not used
--        # For now, if --all is not used, still clear default cache/logs
--        clear_cache_and_logs(lang)
--
--    log_success(get_localized_message("cleanup_complete", lang))
--
--
--@app.command(name="new")
--@error_handler
--def new_project_command(
--    project_name: str = typer.Argument(..., help=get_localized_message("project_name_arg_help", _initial_lang)),
--    output_dir: Path = typer.Option(
--        Path.cwd(),
--        "--output", "-o",
--        help=get_localized_message("output_dir_option_help", _initial_lang),
--        exists=False,
--        file_okay=False,
--        dir_okay=True,
--        writable=True,
--        resolve_path=True
--    ),
--    template_config_file: Path = typer.Option(
--        app_config.GENERATOR_TEMPLATES_DIR_PATH / "project_template.yaml",
--        "--template-config", "-t",
--        help=get_localized_message("template_config_option_help", _initial_lang),
--        exists=True,
--        file_okay=True,
--        dir_okay=False,
--        readable=True,
--        resolve_path=True
--    ),
--    skip_confirmation: bool = typer.Option(False, "--yes", "-y", help=get_localized_message("skip_confirmation_option_help", _initial_lang)),
--    components: Optional[List[str]] = typer.Option(
--        None,
--        "--component", "-c",
--        help=get_localized_message("component_option_help", _initial_lang),
--    ),
--    features: Optional[List[str]] = typer.Option(
--        None,
--        "--feature", "-f",
--        help=get_localized_message("feature_option_help", _initial_lang),
--    ),
--    values: Optional[List[str]] = typer.Option(
--        None,
--        "--value", "-v",
--        help=get_localized_message("value_option_help", _initial_lang),
--    ),
--):
--    """
--    Generates a new project based on the selected template and features.
--    """
--    lang = detect_system_language()
--    log_info(get_localized_message("generating_new_project", lang, name=project_name, dir=output_dir))
--
--    template_manager = get_template_manager()
--    security_manager = get_security_manager() # For token generation in templates
--    app_queue = get_app_queue() # For post-generation commands
--
--    project_slug = project_name.lower().replace(" ", "-").replace("_", "-")
--    project_root = output_dir / project_slug
--
--    if project_root.exists():
--        if Confirm.ask(get_localized_message("project_dir_exists_prompt", lang, dir=project_root), default=False, console=console):
--            shutil.rmtree(project_root)
--            log_warning(get_localized_message("existing_project_dir_removed", lang, dir=project_root))
--        else:
--            log_error(get_localized_message("project_generation_cancelled", lang))
--            raise typer.Exit(1)
--
--    try:
--        # 1. Load Project Structure Configuration
--        log_info(get_localized_message("loading_project_config", lang, file=template_config_file))
--        # Use template manager to load config as a template first for Jinja pre-processing
--        template_content = template_manager.render_template(str(template_config_file.relative_to(app_config.GENERATOR_TEMPLATES_DIR_PATH)), context={
--            "app_config": app_config,
--            "security_manager": security_manager,
--            "project": {
--                "name": project_name,
--                "slug": project_slug,
--                "output_dir": str(project_root) # For template rendering if needed
--            }
--        })
--        project_config_data = yaml.safe_load(template_content)
--        project_structure = ProjectStructureConfig(**project_config_data)
--        log_success(get_localized_message("project_config_loaded", lang))
--
--        # 2. Collect user choices (Features, Values, Components)
--        selected_components_names: Set[str] = set()
--        chosen_feature_flags: Dict[str, bool] = {} # {feature_name: value}
--        chosen_value_features: Dict[str, Union[str, int, bool]] = {} # {value_name: value}
--
--        # Pre-process CLI provided components/features/values
--        if components:
--            selected_components_names.update(components)
--        if features:
--            for f in features:
--                if "=" in f: # e.g., --feature "debug_mode=true"
--                    key, val = f.split("=", 1)
--                    chosen_feature_flags[key] = val.lower() == 'true'
--                else: # e.g., --feature "debug_mode" (implies true)
--                    chosen_feature_flags[f] = True
--        if values:
--            for v in values:
--                if "=" in v:
--                    key, val = v.split("=", 1)
--                    chosen_value_features[key] = val # Store as string, convert type later
--
--        # Interactive prompts for global features/values if not provided via CLI
--        log_info(get_localized_message("collecting_user_input", lang))
--
--        # Global Feature Flags
--        for flag_name, flag_obj in project_structure.global_feature_flags.items():
--            if flag_name not in chosen_feature_flags:
--                prompt_text = get_localized_message("prompt_enable_feature", lang, feature_name=flag_obj.description)
--                chosen_feature_flags[flag_name] = Confirm.ask(prompt_text, default=flag_obj.default, console=console)
--            else:
--                log_debug(f"Global feature '{flag_name}' overridden by CLI to {chosen_feature_flags[flag_name]}.")
--
--        # Global Value Features
--        for value_name, value_obj in project_structure.global_value_features.items():
--            if value_name not in chosen_value_features:
--                prompt_text = value_obj.prompt or get_localized_message("prompt_enter_value", lang, value_name=value_obj.description, default=value_obj.default)
--                user_input = Prompt.ask(prompt_text, default=str(value_obj.default), console=console)
--                try:
--                    if value_obj.type == "int":
--                        chosen_value_features[value_name] = int(user_input)
--                    elif value_obj.type == "bool":
--                        chosen_value_features[value_name] = user_input.lower() in ['true', '1', 'yes', 'y']
--                    else: # str
--                        chosen_value_features[value_name] = user_input
--                except ValueError:
--                    log_warning(get_localized_message("invalid_value_type_warning", lang, value=user_input, type=value_obj.type, name=value_name))
--                    console.print(f"[{WARNING_STYLE}]{get_localized_message('invalid_value_type_warning', lang, value=user_input, type=value_obj.type, name=value_name)}. Using default.[/]")
--                    chosen_value_features[value_name] = value_obj.default # Fallback to default
--            else:
--                # Convert CLI provided value to correct type based on schema
--                try:
--                    cli_val = chosen_value_features[value_name]
--                    if value_obj.type == "int":
--                        chosen_value_features[value_name] = int(cli_val)
--                    elif value_obj.type == "bool":
--                        chosen_value_features[value_name] = str(cli_val).lower() in ['true', '1', 'yes', 'y']
--                    # str is already handled
--                except ValueError:
--                    log_warning(f"CLI provided value '{cli_val}' for '{value_name}' cannot be converted to type '{value_obj.type}'. Using default.")
--                    console.print(f"[{WARNING_STYLE}]CLI provided value '{cli_val}' for '{value_name}' cannot be converted to type '{value_obj.type}'. Using default.[/]")
--                    chosen_value_features[value_name] = value_obj.default
--                log_debug(f"Global value '{value_name}' overridden by CLI to {chosen_value_features[value_name]}.")
--
--        # Component Selection
--        available_component_names = [comp.name for comp in project_structure.components]
--        if not components: # If no components provided via CLI, prompt interactively
--            console.print(Panel(get_localized_message("select_components_title", lang), expand=False, style=INFO_STYLE))
--            for i, comp in enumerate(project_structure.components):
--                console.print(f"  [bold blue]{i+1}. {comp.name}[/bold blue] - [cyan]{comp.description}[/cyan]")
--
--            selected_indices: List[int] = []
--            while True:
--                input_str = Prompt.ask(get_localized_message("prompt_select_components", lang), default="", console=console)
--                if not input_str: # Allow skipping if no components required
--                    break
--                try:
--                    current_selection = sorted(list(set(int(x.strip()) for x in input_str.split(','))))
--                    if all(1 <= idx <= len(project_structure.components) for idx in current_selection):
--                        selected_indices = current_selection
--                        break
--                    else:
--                        console.print(f"[{WARNING_STYLE}]{get_localized_message('invalid_component_selection', lang)}[/]")
--                except ValueError:
--                    console.print(f"[{WARNING_STYLE}]{get_localized_message('invalid_input', lang)}[/]")
--            selected_components_names.update(project_structure.components[idx-1].name for idx in selected_indices)
--        else:
--            # Validate CLI components
--            for comp_name in selected_components_names:
--                if comp_name not in available_component_names:
--                    raise ValidationError(get_localized_message("invalid_component_cli", lang, component=comp_name, available=", ".join(available_component_names)))
--            log_debug(f"Components selected via CLI: {selected_components_names}")
--
--
--        # Component-specific optional features
--        component_feature_choices: Dict[str, Dict[str, bool]] = {} # {comp_name: {feature_name: value}}
--        for comp in project_structure.components:
--            if comp.name in selected_components_names:
--                component_feature_choices[comp.name] = {}
--                for feat_name, feat_desc in comp.optional_features.items():
--                    # Check if this feature was explicitly set via CLI (--feature component_name.feature_name=true)
--                    cli_override_key = f"{comp.name}.{feat_name}"
--                    if cli_override_key in chosen_feature_flags:
--                        component_feature_choices[comp.name][feat_name] = chosen_feature_flags[cli_override_key]
--                        log_debug(f"Component feature '{cli_override_key}' overridden by CLI to {chosen_feature_flags[cli_override_key]}.")
--                    else:
--                        prompt_text = get_localized_message("prompt_enable_component_feature", lang, component_name=comp.name, feature_name=feat_desc)
--                        component_feature_choices[comp.name][feat_name] = Confirm.ask(prompt_text, default=False, console=console) # Default to false for optional features
--
--        # 3. Prepare Jinja2 Context
--        global_context: Dict[str, Any] = {
--            "project": {
--                "name": project_name,
--                "slug": project_slug,
--                "current_year": datetime.now().year,
--                "author": app_config.AUTHOR,
--                "version": app_config.APP_VERSION,
--                "description": project_structure.description,
--                "root_dir": str(project_root)
--            },
--            "global_features": chosen_feature_flags, # Renamed from 'features' to avoid confusion with component features
--            "value_features": chosen_value_features,
--            "component_features": component_feature_choices, # New: {comp_name: {feat_name: bool}}
--            "app_config": app_config, # Access global app configuration
--            "security_manager": security_manager, # Access security manager for token generation
--        }
--        # Fix: Only log serializable parts of global_context to avoid JSON serialization errors
--        try:
--            serializable_context = {k: v for k, v in global_context.items() if isinstance(v, (str, int, float, bool, list, dict, type(None)))}
--            log_debug(f"Jinja2 Context: {json.dumps(serializable_context, indent=2)}")
--        except Exception as e:
--            log_debug(f"Could not serialize global_context for debug: {e}")
--
--        if not skip_confirmation:
--            console.print(Panel(get_localized_message("project_summary_title", lang), expand=False, style=INFO_STYLE))
--            console.print(f"[bold]Project Name:[/bold] {project_name}")
--            console.print(f"[bold]Output Directory:[/bold] {project_root}")
--            console.print("[bold]Global Features:[/bold]")
--            if global_context["global_features"]:
--                for k, v in global_context["global_features"].items():
--                    console.print(f"  - {k}: [magenta]{v}[/magenta]")
--            else:
--                console.print("  [dim]None[/dim]")
--
--            console.print("[bold]Global Values:[/bold]")
--            if global_context["value_features"]:
--                for k, v in global_context["value_features"].items():
--                    console.print(f"  - {k}: [magenta]{v}[/magenta] (Type: {project_structure.global_value_features.get(k).type})")
--            else:
--                console.print("  [dim]None[/dim]")
--
--            console.print("[bold]Selected Components:[/bold]")
--            if selected_components_names:
--                for comp_name in selected_components_names:
--                    console.print(f"  - [green]{comp_name}[/green]")
--                    if comp_name in component_feature_choices:
--                        for feat_name, enabled in component_feature_choices[comp_name].items():
--                            console.print(f"    - Feature '{feat_name}': [magenta]{enabled}[/magenta]")
--            else:
--                console.print("  [dim]None[/dim]")
--
--            if not Confirm.ask(get_localized_message("proceed_with_generation_prompt", lang), default=True, console=console):
--                log_info(get_localized_message("project_generation_cancelled", lang))
--                raise typer.Exit(1)
--
--        # 4. Create Project Root Directory
--        log_info(get_localized_message("creating_project_root", lang, path=project_root))
--        project_root.mkdir(parents=True, exist_ok=False)
--        log_success(get_localized_message("project_root_created", lang, path=project_root))
--
--        # 5. Create root .env and .gitignore files
--        create_root_project_files(project_root, global_context, lang)
--
--        # 6. Generate Project Components
--        with Progress(
--            SpinnerColumn(),
--            TextColumn("[progress.description]{task.description}"),
--            BarColumn(),
--            TaskProgressColumn(),
--            TimeRemainingColumn(),
--            TimeElapsedColumn(),
--            console=console
--        ) as progress:
--            main_task = progress.add_task(get_localized_message("generating_components_progress", lang), total=len(selected_components_names) + 1) # +1 for root files
--
--            # Mark root files task as complete (it's already done)
--            progress.update(main_task, advance=1)
--
--            for component_config in project_structure.components:
--                if component_config.name in selected_components_names:
--                    log_info(get_localized_message("generating_component", lang, component=component_config.name))
--                    component_task = progress.add_task(f"[bold magenta]{component_config.name}[/bold magenta]", total=1) # Task per component
--
--                    # Render the component's output path in case it contains Jinja2 variables
--                    rendered_output_path_str = template_manager.render_string(component_config.output_path, global_context)
--                    component_output_path = project_root / rendered_output_path_str
--                    component_output_path.mkdir(parents=True, exist_ok=True)
--                    log_debug(f"Component '{component_config.name}' output path: {component_output_path}")
--
--                    # Process files
--                    for file_config in component_config.files:
--                        condition_met = True
--                        if file_config.condition:
--                            try:
--                                # Evaluate Jinja2 condition
--                                condition_met = template_manager.render_string("{{ " + file_config.condition + " }}", global_context).lower() == 'true'
--                            except Exception as e:
--                                log_warning(f"Failed to evaluate condition '{file_config.condition}' for file '{file_config.source}': {e}. Skipping file.", error_obj=e)
--                                console.print(f"[{WARNING_STYLE}]{get_localized_message('condition_eval_failed_warning', lang, file=file_config.source, condition=file_config.condition)}[/]")
--                                condition_met = False
--
--                        if condition_met:
--                            source_file_rel_path = Path(component_config.template_path) / file_config.source
--                            # Render rename path if it contains Jinja2
--                            final_file_name = file_config.source
--                            if file_config.rename:
--                                final_file_name = template_manager.render_string(file_config.rename, global_context)
--                            # Remove .jinja suffix if present in source and output
--                            if source_file_rel_path.suffix == ".jinja":
--                                final_file_name = Path(final_file_name).stem # Remove .jinja from output name
--                            destination_file_path = component_output_path / final_file_name
--
--                            template_manager.copy_and_render_template_file(
--                                source_file_rel_path,
--                                destination_file_path,
--                                global_context,
--                                lang
--                            )
--
--                    # Process directories
--                    for dir_config in component_config.directories:
--                        condition_met = True
--                        if dir_config.condition:
--                            try:
--                                condition_met = template_manager.render_string("{{ " + dir_config.condition + " }}", global_context).lower() == 'true'
--                            except Exception as e:
--                                log_warning(f"Failed to evaluate condition '{dir_config.condition}' for directory '{dir_config.source}': {e}. Skipping directory.", error_obj=e)
--                                console.print(f"[{WARNING_STYLE}]{get_localized_message('condition_eval_failed_warning', lang, file=dir_config.source, condition=dir_config.condition)}[/]")
--                                condition_met = False
--
--                        if condition_met:
--                            source_dir_rel_path = Path(component_config.template_path) / dir_config.source
--                            # Render rename path if it contains Jinja2
--                            final_dir_name = dir_config.source
--                            if dir_config.rename:
--                                final_dir_name = template_manager.render_string(dir_config.rename, global_context)
--
--                            destination_dir_path = component_output_path / final_dir_name
--
--                            template_manager.copy_and_render_template_directory(
--                                source_dir_rel_path,
--                                destination_dir_path,
--                                global_context,
--                                lang,
--                                component_output_path # Pass the component's actual output path
--                            )
--
--                    # Add post-generation commands to queue
--                    for command_config in component_config.post_generation_commands:
--                        command_list = command_config["command"]
--                        condition_met_for_command = True
--                        if "condition" in command_config:
--                            try:
--                                condition_met_for_command = template_manager.render_string("{{ " + command_config["condition"] + " }}", global_context).lower() == 'true'
--                            except Exception as e:
--                                log_warning(f"Failed to evaluate condition '{command_config['condition']}' for post-gen command '{command_list}': {e}. Skipping command.", error_obj=e)
--                                console.print(f"[{WARNING_STYLE}]{get_localized_message('condition_eval_failed_warning', lang, file='post-gen command', condition=command_config['condition'])}[/]")
--                                condition_met_for_command = False
--
--                        if condition_met_for_command:
--                            # Render command arguments with Jinja2 context if they contain variables
--                            rendered_command_list = [template_manager.render_string(arg, global_context) for arg in command_list]
--                            app_queue.add_task(
--                                run_command,
--                                rendered_command_list,
--                                component_output_path, # Run command in component's root
--                                get_localized_message("running_post_gen_command", lang, command=" ".join(rendered_command_list[:3]) + "..."),
--                                lang,
--                                get_localized_message("post_gen_command_failed", lang, command=" ".join(rendered_command_list[:3]) + "..."),
--                                # progress_task=main_task # Optionally link to main task for progress updates
--                            )
--                            log_debug(f"Added post-generation command to queue: {rendered_command_list}")
--
--                    progress.update(component_task, advance=1) # Mark component task complete
--                    log_success(get_localized_message("component_generated_success", lang, component=component_config.name))
--            progress.stop_task(main_task)
--
--        log_success(get_localized_message("project_generation_complete", lang, name=project_name, path=project_root))
--
--        # 7. Run Post-Generation Commands (from queue)
--        if not app_queue.is_empty():
--            console.print(Panel(get_localized_message("running_post_gen_commands_title", lang), expand=False, style=INFO_STYLE))
--            app_queue.run_all_tasks(with_progress=True, lang=lang)
--            log_success(get_localized_message("all_post_gen_commands_complete", lang))
--        else:
--            log_info(get_localized_message("no_post_gen_commands", lang))
--
--        console.print(Panel(get_localized_message("next_steps_title", lang), expand=False, style=SUCCESS_STYLE))
--        console.print(get_localized_message("next_steps_cd", lang, project_path=project_root))
--        console.print(get_localized_message("next_steps_install_deps", lang))
--        console.print(get_localized_message("next_steps_run_app", lang))
--        console.print(get_localized_message("next_steps_read_docs", lang, docs_path=f"{project_root}/docs"))
--
--
--    except ValidationError as e:
--        log_error(f"Project configuration validation failed: {e.message}", lang=lang, error_obj=e.original_exception)
--        console.print(f"[{ERROR_STYLE}]{get_localized_message('project_config_validation_failed', lang, error=e.message)}[/]", style=ERROR_STYLE)
--        raise typer.Exit(1)
--    except AppError as e:
--        log_error(f"Project generation failed: {e.message}", lang=lang, error_obj=e.original_exception)
--        console.print(
--            f"[{ERROR_STYLE}]{get_localized_message('project_generation_failed', lang, error=e.message, default='Project generation failed: {error}')}"
--            f"[/]", style=ERROR_STYLE
--        )
--        raise typer.Exit(1)
--    except Exception as e:
--        log_critical(f"An unexpected error occurred during project generation: {e}", lang=lang, error_obj=e)
--        console.print(
--            f"[{ERROR_STYLE}]{get_localized_message('project_generation_failed_unexpected', lang, error=str(e), default='An unexpected error occurred during project generation: {error}')}"
--            f"[/]", style=ERROR_STYLE
--        )
--        raise typer.Exit(1)
--
--def create_root_project_files(project_root: Path, global_context: Dict[str, Any], lang: str):
--    """
--    Creates the root .env and .gitignore files for the new project.
--    These are generated from simple Jinja strings defined in localization files.
--    """
--    template_manager = get_template_manager()
--    try:
--        # Create .env file
--        env_template_content = get_localized_message("root_env_template", lang)
--        env_content = template_manager.render_string(env_template_content, global_context)
--        (project_root / ".env").write_text(env_content, encoding='utf-8')
--        log_success(get_localized_message("root_env_created", lang), lang=lang)
--
--        # Create .gitignore file
--        gitignore_template_content = get_localized_message("root_gitignore_template", lang)
--        gitignore_content = template_manager.render_string(gitignore_template_content, global_context)
--        (project_root / ".gitignore").write_text(gitignore_content, encoding='utf-8')
--        log_success(get_localized_message("root_gitignore_created", lang), lang=lang)
--
--    except AppError as e:
--        log_error(f"Error creating root project files: {e.message}", lang=lang, error_obj=e.original_exception)
--        console.print(f"[{ERROR_STYLE}]{get_localized_message('root_file_creation_failed', lang, error=e.message)}[/]", style=ERROR_STYLE)
--        raise typer.Exit(1)
--    except Exception as e:
--        log_critical(f"An unexpected error occurred creating root project files: {e}", lang=lang, error_obj=e)
--        console.print(f"[{ERROR_STYLE}]{get_localized_message('root_file_creation_failed_unexpected', lang, error=str(e))}[/]", style=ERROR_STYLE)
--        raise typer.Exit(1)
--
--# You need to install the 'typer' package (and optionally 'rich' for better CLI output).
--# Run the following command in your terminal:
--#   pip install typer[all] rich
--
--# Main entry point for Typer app
--if __name__ == "__main__":
--    # Ensure required dependencies are installed
--    try:
--        import typer
--        import rich
--    except ImportError:
--        print("Missing required packages. Please run:\n  pip install typer[all] rich", file=sys.stderr)
--        sys.exit(1)
--    # Ensure logging and localization are set up before any command runs
--    try:
--        app()
--    except typer.Exit:
--        pass
--    except SystemExit:
--        pass # Typer sometimes exits via SystemExit
--    except Exception as e:
--        # Catch any remaining unexpected errors at the very top level
--        log_critical(
--            get_localized_message('unexpected_command_error', _initial_lang, command='application runtime', error=str(e)),
--            lang=_initial_lang,
--            error_obj=e
--        )
--        console.print(f"[{ERROR_STYLE}]{get_localized_message('unexpected_command_error', _initial_lang, command='application runtime', error=str(e))}[/]", style=ERROR_STYLE)
--        sys.exit(1)
-+print("Welcome to GPlus Smart Builder Pro!")
-+# Add your project startup logic here.

```

## src/main.py <-> gplus_smart_builder_pro/src/main.py
- [ ] One or both files missing. Skipped.
## src/main.py <-> gplus-smart-builder-pro/src/main.py
- [ ] One or both files missing. Skipped.
## tests/test_main.py <-> gplus_smart_builder_pro/tests/test_main.py
- [x] Files differed. Merged into tests/test_main.py, removed gplus_smart_builder_pro/tests/test_main.py.
- [ ] Manual review recommended for tests/test_main.py (see diff below):

```
--- tests/test_main.py+++ gplus_smart_builder_pro/tests/test_main.py@@ -1,14 +1,2 @@-from fastapi.testclient import TestClient
-from gplus_smart_builder_pro.src.main import app
-
-client = TestClient(app)
-
-def test_read_root():
-    response = client.get("/")
-    assert response.status_code == 200
-    assert "GPlus Smart Builder Pro API" in response.json()["message"]
-
-def test_get_users():
-    response = client.get("/users")
-    assert response.status_code == 200
-    assert isinstance(response.json(), list)
+def test_main():
+    assert True

```

## tests/test_main.py <-> gplus-smart-builder-pro/tests/test_main.py
- [x] Files differed. Merged into tests/test_main.py, removed gplus-smart-builder-pro/tests/test_main.py.
- [ ] Manual review recommended for tests/test_main.py (see diff below):

```
--- tests/test_main.py+++ gplus-smart-builder-pro/tests/test_main.py@@ -1,16 +0,0 @@---- tests/test_main.py+++ gplus_smart_builder_pro/tests/test_main.py@@ -1,14 +1,2 @@-from fastapi.testclient import TestClient
--from gplus_smart_builder_pro.src.main import app
--
--client = TestClient(app)
--
--def test_read_root():
--    response = client.get("/")
--    assert response.status_code == 200
--    assert "GPlus Smart Builder Pro API" in response.json()["message"]
--
--def test_get_users():
--    response = client.get("/users")
--    assert response.status_code == 200
--    assert isinstance(response.json(), list)
-+def test_main():
-+    assert True

```
