async def list_impacts():
    # استبدل mock بمنطق إنتاجي يتصل بالقاعدة
    return [{"id": 1, "category": "CO2", "score": 12.3}]
